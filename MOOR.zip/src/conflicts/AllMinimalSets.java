/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

import java.util.Iterator;
import conflicts.sets.ObjectiveSet;
import conflicts.sets.SetOfObjectiveSets;

public class AllMinimalSets {

	private FileProblem problem;
	private Population pop;
	private Controller con;

	public void start(String filename, int type, double value) {
		init(filename);
		// Controller:
		this.con = new Controller(this.problem, 1, this.pop, 1, 0);

		java.util.Calendar calendar = new java.util.GregorianCalendar();
		long milliseconds = calendar.getTimeInMillis();
		SetOfObjectiveSets output;
		if (type == 1) {
			output = con.allMinimalSetsDelta(value);
			System.out.println("delta-MOSS problem with given delta= " + value);
			System.out.println("exact algorithm");
			System.out.println("------------------------------------------------------");

		} else {
			int intvalue = (new Double(value)).intValue();
			output = con.allMinimalSetsK(intvalue);
			System.out.println("delta-MOSS problem with given k= " + intvalue);
			System.out.println("exact algorithm");
			System.out.println("------------------------------------------------------");

		}
		Iterator<ObjectiveSet> iter = output.getElements().iterator();
		int i = 1;
		while (iter.hasNext()) {
			ObjectiveSet os = iter.next();
			System.out.println(i + " " + os.size() + "  " + os.toString());
			i++;
		}
		System.out.println("------------------------------------------------------");
		java.util.Calendar calendar2 = new java.util.GregorianCalendar();
		long millis = calendar2.getTimeInMillis();
		System.out.println("Elapsed time during computation: " + (millis - milliseconds) + " milliseconds");
	}

	private void init(String filename) {
		this.problem = new FileProblem(filename);
		this.pop = new FilePopulation(problem);
	}

	/**
	 * Computes the size of the minimum non-redundant set for a given set of
	 * individuals in a file named data.
	 *
	 * @param args
	 *            args[0]: name of file, with information about the individuals
	 *            (data format: "id objectivevalue1 objectivevalue2 ...")
	 *            args[1]/ args[2]: type/value for the two different delta-MOSS
	 *            problems: a) the case of given delta value (type = 1, value =
	 *            delta) and b) the case of given k (type = 2, value = k). if
	 *            only one argument is given, the exact algorithm for MOSS is
	 *            performed
	 * 
	 */
	public static void main(String[] args) {
		AllMinimalSets ams = new AllMinimalSets();
		if (args == null || args.length != 3) {
			System.out.println("computes all minimal objective sets for a Pareto set");
			System.out.println("  approximation given in file filename");
			System.out.println();
			System.out.println("usage:");
			System.out.println("   AllMinimalSets filename type value");
			System.out.println();
			System.out.println("   where type = 1:  delta-MOSS");
			System.out.println("   and   type = 2:  k-EMOSS");
			System.out.println("   and value=delta, resp. value=k ");
		} else {
			String filename = args[0];
			int type = new Integer(args[1]).intValue();
			double value = new Double(args[2]).doubleValue();
			ams.start(filename, type, value);
		}
	}

}
