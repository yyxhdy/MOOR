/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

import java.util.LinkedList;
import conflicts.sets.ObjectiveSet;
import conflicts.sets.TreeSet;

public class DeltaMOSSGreedyAlgorithm {

	// matrix of objective values (columns) for individuals (rows)
	double[][] values = new double[1][1];
	int os_dim = values[0].length;

	static double failure = 0.0000000001;

	Relation[] relations; // an array of the relations $\preceq_i$
	Relation dominanceRelation; // the relation $\preceq$

	public DeltaMOSSGreedyAlgorithm(double[][] d) {
		this.values = d;
		this.os_dim = values[0].length;

		/* preparing for initialization of relations: */
		Population pop = new Population();
		for (int i = 0; i < values.length; i++) {
			boolean[] dv = new boolean[values.length];
			double[] ov = values[i];
			pop.addIndividual(new Individual_BS(i, values.length, this.os_dim, dv, ov));
		}
		this.initRelations(pop);
	}

	public DeltaMOSSGreedyAlgorithm(Population pop) {
		LinkedList<Individual> individuals = pop.getPopulation();
		int size = individuals.size();
		this.os_dim = (individuals.get(0)).os_dim;
		values = new double[size][os_dim];
		for (int i = 0; i < size; i++) {
			Individual ind = individuals.get(i);
			values[i] = ind.getObjectiveVector();
		}
		this.initRelations(pop);
	}

	private void initRelations(Population pop) {
		this.relations = new Relation[this.os_dim];
		for (int i = 0; i < this.os_dim; i++) {
			this.relations[i] = Controller.computeWeakRelation(i, pop);
		}
		this.dominanceRelation = Controller.computeWholeWeakRelation(pop);
	}

	public ObjectiveSet performGreedyAlgorithmGivenK(int k) {
		boolean[] elements = new boolean[this.os_dim];
		ObjectiveSet chosen = new ObjectiveSet(elements, Double.MAX_VALUE);
		int numberOfChosenObjectives = 0;

		while (numberOfChosenObjectives < k && chosen.getDelta() > 0) {
			chosen = computeNewObjectiveSet(chosen);
			numberOfChosenObjectives++;
		}
		return chosen;
	}

	/**
	 * PART OF GREEDY ALGORITHM FOR GIVEN K Returns the chosen objectives in the
	 * next iteration of the greedy algorithm. Given the set of already chosen
	 * objectives in 'chosen', the returned ObjectiveSet conatins all formerly
	 * chosen objectives plus an additional objective that minimizes the
	 * delta-error for this new set of |chosen|+1 objectives. The delta value of
	 * this new ObjectiveSet is computed, too.
	 */
	private ObjectiveSet computeNewObjectiveSet(ObjectiveSet chosen) {
		double delta_min = Double.MAX_VALUE;
		int bestObjective = 0;

		ObjectiveSet chosen_next = null;
		ObjectiveSet notchosen_next = null;
		boolean[] chosenObjectives = chosen.getElements();
		boolean[] notChosenObjectives = new boolean[this.os_dim];
		for (int i = 0; i < this.os_dim; i++) {
			if (!chosenObjectives[i]) {
				notChosenObjectives[i] = true;
			}
		}
		for (int i = 0; i < this.os_dim; i++) {
			/*
			 * test for all non-chosen objectives, if delta-error gets minimal
			 * and store index of this objective in bestObjective:
			 */
			if (!chosenObjectives[i]) {
				/*
				 * add i to chosen objectives and remove i from set of not
				 * chosen ones
				 */
				chosenObjectives[i] = true;
				notChosenObjectives[i] = false;
				chosen_next = new ObjectiveSet(chosenObjectives);
				notchosen_next = new ObjectiveSet(notChosenObjectives);
				double delta = getDeltaMinFor(chosen_next, notchosen_next);
				if (delta < delta_min) {
					delta_min = delta;
					bestObjective = i;
				}
				/*
				 * remove i from chosen objectives and add i from notchosen
				 * again (get invariant working, that chosen and notchosen do
				 * not vary from i to i+1)
				 */
				chosenObjectives[i] = false;
				notChosenObjectives[i] = true;
			}
		}

		// prepare return value:
		chosenObjectives[bestObjective] = true;
		chosen_next = new ObjectiveSet(chosenObjectives, delta_min);

		return chosen_next;
	}

	/**
	 * PART OF GREEDY ALGORITHM FOR GIVEN K returns the minimal delta value such
	 * that the objective subset set1 is delta-nonconflicting with set2.
	 */
	public double getDeltaMinFor(ObjectiveSet set1, ObjectiveSet set2) {
		double delta = 0;
		int numOfInds = values.length;
		for (int i = 0; i < numOfInds; i++) {
			for (int j = 0; j < numOfInds; j++) {
				if (weaklyDominates(i, j, set1)) {
					/*
					 * for all objectives in set2 adjust the delta value
					 * according to the current pair (i,j) of individuals:
					 */
					boolean[] obj = set2.getElements();
					for (int k = 0; k < obj.length; k++) {
						if (obj[k]) {
							delta = Math.max(delta, values[i][k] - values[j][k]);
						}
					}
				}
			}
		}
		return delta;
	}

	/**
	 * PART OF GREEDY ALGORITHM FOR GIVEN K returns true iff individual i weakly
	 * dominates individual j w.r.t. objective subset ef.
	 */
	private boolean weaklyDominates(int i, int j, ObjectiveSet ef) {
		boolean[] objectives = ef.getElements();
		for (int k = 0; k < objectives.length; k++) {
			if (objectives[k]) {
				if (values[i][k] > values[j][k]) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * returns true iff individual i epsilon-dominates individual j w.r.t.
	 * objective subset ef, where the additive epsilon-dominance relation for
	 * minimization is used:
	 * 
	 * i epsilon-dominates j :\Leftrightarrow \forall k\in ef: f_k(i) - epsilon
	 * \leq f_k(j)
	 */
	private boolean epsilonDominates(int i, int j, ObjectiveSet ef, double epsilon) {
		boolean[] objectives = ef.getElements();
		for (int k = 0; k < objectives.length; k++) {
			if (objectives[k]) {
				/* use static variable failure to handle arithmetic errors: */
				if ((values[i][k] - epsilon - failure) > values[j][k]) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Performs the greedy delta-MOSS algorithm as described in bz2006d.
	 *
	 */
	public ObjectiveSet performGreedyAlgorithmGivenDelta(double delta) {
		int a = values.length;
		boolean[][] rel = new boolean[a][a];
		for (int i = 0; i < a; i++) {
			for (int j = 0; j < a; j++) {
				rel[i][j] = true;
			}
		}
		Relation R = new Relation(0, rel);
		R = R.minus(0, this.dominanceRelation);
		boolean[] chosen = new boolean[this.os_dim];

		while (R.numberOfRelatedPairs != 0) {
			Relation smallest = new Relation(System.currentTimeMillis(), rel);
			int smallestSize = Integer.MAX_VALUE;
			int theSmallest = 0;
			for (int i = 0; i < this.os_dim; i++) {
				if (!chosen[i]) {
					chosen[i] = true; // set only temporarily
					Relation zeroDeltaDominance = computeZeroDeltaDominance(chosen, delta);
					Relation current = this.relations[i].intersect(System.currentTimeMillis(), R);
					current = current.minus(System.currentTimeMillis(), zeroDeltaDominance);
					int currentSize = current.getNumberOfRelatedPairs();
					if (currentSize < smallestSize) {
						smallest = current;
						smallestSize = currentSize;
						theSmallest = i;
					}
					chosen[i] = false; // reset the temporarily chsen objective
				}
			}
			R = smallest;
			chosen[theSmallest] = true;
		}

		/* compute correct delta value of chosen objective set: */
		ObjectiveSet chosenObj = new ObjectiveSet(chosen);
		boolean[] notchosen = new boolean[this.os_dim];
		for (int i = 0; i < this.os_dim; i++) {
			notchosen[i] = !chosen[i];
		}
		ObjectiveSet notchosenObj = new ObjectiveSet(notchosen);
		ObjectiveSet ret = new ObjectiveSet(chosen, this.getDeltaMinFor(chosenObj, notchosenObj));

		return ret;
	}

	/**
	 * computes the dominance relation $\preceq^{0,\delta}_{chosen, notchosen}$.
	 */
	private Relation computeZeroDeltaDominance(boolean[] chosen, double delta) {
		int ds_dim = this.values.length;
		Relation zerodelta = new Relation(ds_dim);
		ObjectiveSet chosenSet = new ObjectiveSet(chosen);
		boolean[] notchosen = new boolean[chosen.length];
		for (int i = 0; i < chosen.length; i++) {
			notchosen[i] = !chosen[i];
		}
		ObjectiveSet notchosenSet = new ObjectiveSet(notchosen);
		/* compute the relation between the decision vectors p and q */
		for (int p = 0; p < ds_dim; p++) {
			for (int q = 0; q < ds_dim; q++) {
				if (this.weaklyDominates(p, q, chosenSet) && this.epsilonDominates(p, q, notchosenSet, delta)) {
					zerodelta.setinrelation(p, q, true);
				}
			}
		}
		return zerodelta;
	}

	public ObjectiveSet performGreedyAlgorithm() {
		return performGreedyAlgorithmGivenDelta(0);
	}

	/** Alternative algorithm using the greedy algorithm for given K !!! */
	public ObjectiveSet performGreedyAlgorithmGivenDelta2(double delta) {
		int[] ints = { 1 };
		ObjectiveSet os = new ObjectiveSet(ints, 2, Double.MAX_VALUE);
		int k = 1;
		while (os.getDelta() > delta) {
			os = this.performGreedyAlgorithmGivenK(k);
			k++;
		}
		return os;
	}

	// *********************************************************************************

	/**
	 * Here, the implementation of an alternative greedy algorithm starts. It is
	 * based on a kind of hierarchical clustering of the objectives, cf.
	 * brockho2007a.
	 * 
	 * if method == 0, the choice which objective to choose in the single steps
	 * is determined by the delta-errors between the chosen objectives, e.g. if
	 * A={f_1,f_2,f_3}, chosen obj. f_2 and B={f_4,f_5}, chosen obj. f_4 are
	 * considered, the delta error is computed only for the pair {f_2,f_4} and
	 * the new chosen objective can be either f_2 or f_4.
	 * 
	 * if method == 1, each combination of objectives in the considered sets are
	 * considered, e.g. if A={f_1,f_2,f_3}, chosen obj. f_2 and B={f_4,f_5},
	 * chosen obj. f_4 are considered, the delta error is computed as the
	 * minimum delta error of f_1 wrt. {f_2,f_3,f_4,f_5}, f_2 wrt.
	 * {f_1,f_3,f_4,f_5}, ... f_5 wrt. {f_1,f_2,f_3,f_4} and each objective
	 * within the two sets can become the new chosen objective.
	 * 
	 */

	public void computeTree(int method) {
		if (method == 0) {
			computeTreeWithPairwiseComparison();
		} else if (method == 1 || method == 2) {
			computeTreeWithAllCombinations(method);
		}
	}

	
	public ObjectiveSet computeTreeWithPairwiseComparison(int K) {
		double[][] data = new double[this.os_dim][this.os_dim];

		/* temporary variables: */
		double deltaij;
		double deltaji;

		
		ObjectiveSet res = null;
		double delta = Double.MAX_VALUE;
		/*
		 * initialize objective sets in tree as TreeSets with one objective,
		 * delta=0 (because no objective is omitted) and the single objective as
		 * its chosen objective
		 */
		int[] elements = new int[1];
		TreeSet[] objsets = new TreeSet[this.os_dim];
		for (int i = 0; i < this.os_dim; i++) {
			elements[0] = i;
			objsets[i] = new TreeSet(elements, this.os_dim, 0);
			// constructor of TreeSet chooses already the correct objective!
		}

		/* compute deltas and chosenobjectives: */
		for (int i = 0; i < this.os_dim; i++) {
			for (int j = i + 1; j < this.os_dim; j++) {
				deltaij = getDeltaMinFor(objsets[i], objsets[j]);
				deltaji = getDeltaMinFor(objsets[j], objsets[i]);

				if (deltaij < deltaji) {
					/* choose objective i because of better delta error */
					data[i][j] = deltaij;
					data[j][i] = i;
				} else {
					/* choose objective j because of better delta error */
					data[i][j] = deltaji;
					data[j][i] = j;
				}
			}
		} // end of preprocessing



		/* perform 'os_dim' cycles of merging two objective sets together: */
		TreeSet[] currentObjectiveSets = objsets;
		
		
		if (currentObjectiveSets.length <= K) {
			ObjectiveSet set = new ObjectiveSet(this.os_dim);

			for (int i = 0; i < currentObjectiveSets.length; i++) {
				int obj = currentObjectiveSets[i].getChosenObjective();
				set.add(obj);
			}

			boolean flag[] = new boolean[this.os_dim];

			for (int i = 0; i < this.os_dim; i++)
				flag[i] = true;
			ObjectiveSet allset = new ObjectiveSet(flag);

			double error = getDeltaMinFor(set, allset);

			if (error <= delta) {
				res = set;
				delta = error;
			}

		}
		
		
		for (int k = this.os_dim; k > 1; k--) {
			TreeSet[] newObjectiveSets = new TreeSet[k - 1];

			int besti = 0;
			int bestj = 1;
			double bestDelta = Double.MAX_VALUE;
			/* find objective sets with smallest delta for merging: */
			for (int i = 0; i < currentObjectiveSets.length; i++) {
				for (int j = i + 1; j < currentObjectiveSets.length; j++) {
					if (data[currentObjectiveSets[i].getChosenObjective()][currentObjectiveSets[j]
							.getChosenObjective()] < bestDelta) {
						besti = i;
						bestj = j;
						bestDelta = data[currentObjectiveSets[besti].getChosenObjective()][currentObjectiveSets[bestj]
								.getChosenObjective()];
					}
				}
			}
			for (int i = 0; i < k; i++) {
				if (i < besti) {
					newObjectiveSets[i] = currentObjectiveSets[i];
				} else if (i == besti) {
					/*
					 * compute merged objective set with new delta error as
					 * maximum of the errors of smaller sets and the error
					 * between obj_besti and obj_bestj
					 */

					int chosenObj1 = currentObjectiveSets[besti].getChosenObjective();
					int chosenObj2 = currentObjectiveSets[bestj].getChosenObjective();
					/*
					 * guarantee that chosenObj1 < chosenObj2 for accessing
					 * data[chosenObj1][chosneObj2]
					 */
					if (chosenObj1 > chosenObj2) {
						int temp = chosenObj1;
						chosenObj1 = chosenObj2;
						chosenObj2 = temp;
					}
					newObjectiveSets[i] = new TreeSet(currentObjectiveSets[besti], currentObjectiveSets[bestj],
							Math.max(Math.max(data[chosenObj1][chosenObj2], currentObjectiveSets[besti].getDelta()),
									currentObjectiveSets[bestj].getDelta()),
							new Double(data[chosenObj2][chosenObj1]).intValue());
				} else if (i < bestj) {
					newObjectiveSets[i] = currentObjectiveSets[i];
				} else if (i > bestj) {
					newObjectiveSets[i - 1] = currentObjectiveSets[i];
				}
			}


			currentObjectiveSets = newObjectiveSets;
			
			if (currentObjectiveSets.length <= K) {
				ObjectiveSet set = new ObjectiveSet(this.os_dim);
				
				for (int i = 0; i < currentObjectiveSets.length; i++) {
					int obj = currentObjectiveSets[i].getChosenObjective();
					set.add(obj);
				}
				
				boolean flag[] = new boolean[this.os_dim];
				
				for (int i = 0; i < this.os_dim; i++)
					flag[i] = true;
				ObjectiveSet allset = new ObjectiveSet(flag);
				
				
				double error = getDeltaMinFor(set, allset);
				
				if (res == null) {
					res = set;
					delta = error;
				}
				else {
					if (error <= delta) {
						res = set;
						delta = error;
					}
				}
				
				
			}
		}

		res.setDelta(delta);
		return res;
	}
	
	
	private void computeTreeWithPairwiseComparison() {
		/*
		 * preprocessing: compute minimal delta-errors between all objective
		 * pairs (i,j) and corresponding objective, with which the smaller error
		 * can be achieved.
		 * 
		 * delta-error of objective pair (i,j) stands in data[i][j], the
		 * corresponding chosen objective in data[j][i].
		 */
		double[][] data = new double[this.os_dim][this.os_dim];

		/* temporary variables: */
		double deltaij;
		double deltaji;

		/*
		 * initialize objective sets in tree as TreeSets with one objective,
		 * delta=0 (because no objective is omitted) and the single objective as
		 * its chosen objective
		 */
		int[] elements = new int[1];
		TreeSet[] objsets = new TreeSet[this.os_dim];
		for (int i = 0; i < this.os_dim; i++) {
			elements[0] = i;
			objsets[i] = new TreeSet(elements, this.os_dim, 0);
			// constructor of TreeSet chooses already the correct objective!
		}

		/* compute deltas and chosenobjectives: */
		for (int i = 0; i < this.os_dim; i++) {
			for (int j = i + 1; j < this.os_dim; j++) {
				deltaij = getDeltaMinFor(objsets[i], objsets[j]);
				deltaji = getDeltaMinFor(objsets[j], objsets[i]);

				if (deltaij < deltaji) {
					/* choose objective i because of better delta error */
					data[i][j] = deltaij;
					data[j][i] = i;
				} else {
					/* choose objective j because of better delta error */
					data[i][j] = deltaji;
					data[j][i] = j;
				}
			}
		} // end of preprocessing

		/* print current objective sets: */
		for (int i = 0; i < objsets.length; i++) {
			System.out.println(objsets[i].toString());
		}

		/* perform 'os_dim' cycles of merging two objective sets together: */
		TreeSet[] currentObjectiveSets = objsets;
		for (int k = this.os_dim; k > 1; k--) {
			TreeSet[] newObjectiveSets = new TreeSet[k - 1];

			int besti = 0;
			int bestj = 1;
			double bestDelta = Double.MAX_VALUE;
			/* find objective sets with smallest delta for merging: */
			for (int i = 0; i < currentObjectiveSets.length; i++) {
				for (int j = i + 1; j < currentObjectiveSets.length; j++) {
					if (data[currentObjectiveSets[i].getChosenObjective()][currentObjectiveSets[j]
							.getChosenObjective()] < bestDelta) {
						besti = i;
						bestj = j;
						bestDelta = data[currentObjectiveSets[besti].getChosenObjective()][currentObjectiveSets[bestj]
								.getChosenObjective()];
					}
				}
			}
			for (int i = 0; i < k; i++) {
				if (i < besti) {
					newObjectiveSets[i] = currentObjectiveSets[i];
				} else if (i == besti) {
					/*
					 * compute merged objective set with new delta error as
					 * maximum of the errors of smaller sets and the error
					 * between obj_besti and obj_bestj
					 */

					int chosenObj1 = currentObjectiveSets[besti].getChosenObjective();
					int chosenObj2 = currentObjectiveSets[bestj].getChosenObjective();
					/*
					 * guarantee that chosenObj1 < chosenObj2 for accessing
					 * data[chosenObj1][chosneObj2]
					 */
					if (chosenObj1 > chosenObj2) {
						int temp = chosenObj1;
						chosenObj1 = chosenObj2;
						chosenObj2 = temp;
					}
					newObjectiveSets[i] = new TreeSet(currentObjectiveSets[besti], currentObjectiveSets[bestj],
							Math.max(Math.max(data[chosenObj1][chosenObj2], currentObjectiveSets[besti].getDelta()),
									currentObjectiveSets[bestj].getDelta()),
							new Double(data[chosenObj2][chosenObj1]).intValue());
				} else if (i < bestj) {
					newObjectiveSets[i] = currentObjectiveSets[i];
				} else if (i > bestj) {
					newObjectiveSets[i - 1] = currentObjectiveSets[i];
				}
			}

			/* print new objective set: */
			System.out.println("-------------------------------------");
			for (int i = 0; i < newObjectiveSets.length; i++) {
				System.out.println(newObjectiveSets[i].toString());
			}
			currentObjectiveSets = newObjectiveSets;
		}
	}
	
	
	
	
	
	

	/*
	 * if method == 1, the delta error between the single objectives and all
	 * objectives within the corresponding subsets if method == 2, the delta
	 * error between the single objectives and the entire objective set
	 */
	private void computeTreeWithAllCombinations(int method) {
		/*
		 * initialize objective sets in tree as TreeSets with one objective,
		 * delta=0 (because no objective is omitted) and the single objective as
		 * its chosen objective
		 */
		int[] elements = new int[1];
		TreeSet[] objsets = new TreeSet[this.os_dim];
		for (int i = 0; i < this.os_dim; i++) {
			elements[0] = i;
			objsets[i] = new TreeSet(elements, this.os_dim, 0);
			/*
			 * Note, that constructor of TreeSet already chooses the correct
			 * objective!
			 */
		}

		/* print current objective sets: */
		for (int i = 0; i < objsets.length; i++) {
			System.out.println(objsets[i].toString());
		}

		/* perform 'os_dim' cycles of merging two objective sets together: */
		TreeSet[] currentObjectiveSets = objsets;
		for (int k = this.os_dim; k > 1; k--) {
			TreeSet[] newObjectiveSets = new TreeSet[k - 1];

			int besti = 0;
			int bestj = 1;
			double bestDelta = Double.MAX_VALUE;
			int bestChosen = -1; // this objective should be chosen to achieve
									// the best delta
									// NOTE: this objective can be in
									// {0,...,os_dim -1} !!!

			/* find objective sets with smallest delta for merging: */
			for (int i = 0; i < currentObjectiveSets.length; i++) {
				for (int j = i + 1; j < currentObjectiveSets.length; j++) {
					TreeSet currentBest = getCurrentBest(currentObjectiveSets[i], currentObjectiveSets[j], method);
					if (currentBest.getDelta() < bestDelta) {
						besti = i;
						bestj = j;
						bestDelta = currentBest.getDelta();
						bestChosen = currentBest.getChosenObjective();
					}
				}
			}
			for (int i = 0; i < k; i++) {
				if (i < besti) {
					newObjectiveSets[i] = currentObjectiveSets[i];
				} else if (i == besti) {
					/*
					 * compute merged objective set with new delta error as
					 * maximum of the errors of smaller sets and the error
					 * between obj_besti and obj_bestj
					 */
					int chosenObj1 = currentObjectiveSets[besti].getChosenObjective();
					int chosenObj2 = currentObjectiveSets[bestj].getChosenObjective();
					/*
					 * guarantee that chosenObj1 < chosenObj2 for accessing
					 * data[chosenObj1][chosneObj2]
					 */
					if (chosenObj1 > chosenObj2) {
						int temp = chosenObj1;
						chosenObj1 = chosenObj2;
						chosenObj2 = temp;
					}
					newObjectiveSets[i] = new TreeSet(currentObjectiveSets[besti], currentObjectiveSets[bestj],
							bestDelta, bestChosen);
				} else if (i < bestj) {
					newObjectiveSets[i] = currentObjectiveSets[i];
				} else if (i > bestj) {
					newObjectiveSets[i - 1] = currentObjectiveSets[i];
				}
			}

			/* print new objective set: */
			System.out.println("-------------------------------------");
			for (int i = 0; i < newObjectiveSets.length; i++) {
				System.out.println(newObjectiveSets[i].toString());
			}
			currentObjectiveSets = newObjectiveSets;
		}
	}
	
	
	
	public ObjectiveSet computeTreeWithAllCombinationsK(int K) {
		/*
		 * initialize objective sets in tree as TreeSets with one objective,
		 * delta=0 (because no objective is omitted) and the single objective as
		 * its chosen objective
		 */
		int[] elements = new int[1];
		TreeSet[] objsets = new TreeSet[this.os_dim];
		for (int i = 0; i < this.os_dim; i++) {
			elements[0] = i;
			objsets[i] = new TreeSet(elements, this.os_dim, 0);
			/*
			 * Note, that constructor of TreeSet already chooses the correct
			 * objective!
			 */
		}

		/* print current objective sets: */
/*		for (int i = 0; i < objsets.length; i++) {
			System.out.println(objsets[i].toString());
		}*/

		/* perform 'os_dim' cycles of merging two objective sets together: */
		TreeSet[] currentObjectiveSets = objsets;
		for (int k = this.os_dim; k > K; k--) {
			TreeSet[] newObjectiveSets = new TreeSet[k - 1];

			int besti = 0;
			int bestj = 1;
			double bestDelta = Double.MAX_VALUE;
			int bestChosen = -1; // this objective should be chosen to achieve
									// the best delta
									// NOTE: this objective can be in
									// {0,...,os_dim -1} !!!

			/* find objective sets with smallest delta for merging: */
			for (int i = 0; i < currentObjectiveSets.length; i++) {
				for (int j = i + 1; j < currentObjectiveSets.length; j++) {
					TreeSet currentBest = getCurrentBest(currentObjectiveSets[i], currentObjectiveSets[j], 1);
					if (currentBest.getDelta() < bestDelta) {
						besti = i;
						bestj = j;
						bestDelta = currentBest.getDelta();
						bestChosen = currentBest.getChosenObjective();
					}
				}
			}
			for (int i = 0; i < k; i++) {
				if (i < besti) {
					newObjectiveSets[i] = currentObjectiveSets[i];
				} else if (i == besti) {
					/*
					 * compute merged objective set with new delta error as
					 * maximum of the errors of smaller sets and the error
					 * between obj_besti and obj_bestj
					 */
					int chosenObj1 = currentObjectiveSets[besti].getChosenObjective();
					int chosenObj2 = currentObjectiveSets[bestj].getChosenObjective();
					/*
					 * guarantee that chosenObj1 < chosenObj2 for accessing
					 * data[chosenObj1][chosneObj2]
					 */
					if (chosenObj1 > chosenObj2) {
						int temp = chosenObj1;
						chosenObj1 = chosenObj2;
						chosenObj2 = temp;
					}
					newObjectiveSets[i] = new TreeSet(currentObjectiveSets[besti], currentObjectiveSets[bestj],
							bestDelta, bestChosen);
				} else if (i < bestj) {
					newObjectiveSets[i] = currentObjectiveSets[i];
				} else if (i > bestj) {
					newObjectiveSets[i - 1] = currentObjectiveSets[i];
				}
			}

			/* print new objective set: */
/*			System.out.println("-------------------------------------");
			for (int i = 0; i < newObjectiveSets.length; i++) {
				System.out.println(newObjectiveSets[i].toString());
			}*/
			currentObjectiveSets = newObjectiveSets;
		}
		
		ObjectiveSet res = new ObjectiveSet(this.os_dim);
		
		for (int i = 0; i < currentObjectiveSets.length; i++) {
			int obj = currentObjectiveSets[i].getChosenObjective();
			res.add(obj);
		}
		
		boolean flag[] = new boolean[this.os_dim];
		
		for (int i = 0; i < this.os_dim; i++)
			flag[i] = true;
		ObjectiveSet allset = new ObjectiveSet(flag);
		
		
		double delta = getDeltaMinFor(res, allset);
		
	
		res.setDelta(delta);
		return res;
	}
	
	
	
	

	/**
	 * PART OF TREE-BASED GREEDY ALGORITHM returns a TreeSet with error delta
	 * and chosen objective chosenObj, where delta is the minimum error over all
	 * possible single objectives wrt. the remaining objectives in ObjSet1 \cup
	 * objSet2.
	 * 
	 * if method == 1, the delta error between the single objectives and all
	 * objectives within the corresponding subsets if method == 2, TODO THIS IS
	 * NOT CORRECTLY IMPLEMENTED YET !!! the delta error between the single
	 * objectives and the entire objective set
	 */
	private TreeSet getCurrentBest(TreeSet objSet1, TreeSet objSet2, int method) {
		double currentBestDelta = Double.MAX_VALUE;
		int currentBestChosen = -1;
		TreeSet ret = new TreeSet();

		/*
		 * store all elements in objSet1 \cup objSet2 within variable 'element':
		 */
		ObjectiveSet objSet = new ObjectiveSet(objSet1);
		objSet.addAll(objSet2);
		boolean[] element = objSet.getElements();

		/* instantiate an ObjectiveSet with all objectives: */
		boolean[] a = new boolean[this.os_dim];
		for (int s = 0; s < a.length; s++) {
			a[s] = true;
		}
		ObjectiveSet allObjectives = new ObjectiveSet(a);

		for (int i = 0; i < element.length; i++) {
			if (element[i]) {
				/* temporary variables (NOT FAST AND CLEVERLY IMPLEMENTED): */
				boolean[] e = new boolean[this.os_dim];
				boolean[] rest = objSet.getComplement();
				for (int s = 0; s < e.length; s++) {
					e[s] = false;
				}
				e[i] = true;
				rest[i] = true;
				double delta = -1;
				/*
				 * compute delta error between objective i and rest according to
				 * method:
				 */
				if (method == 1) {
					delta = getDeltaMinFor(new ObjectiveSet(e), objSet);
				} else if (method == 2) {
					delta = getDeltaMinFor(new ObjectiveSet(rest), allObjectives);
				}

				System.out.println("i=" + i + " and delta=" + delta);

				/* decide whether objective i is best objective */
				if (delta < currentBestDelta) {
					currentBestDelta = delta;
					currentBestChosen = i;
				}
			}
		}

		ret.setDelta(currentBestDelta);
		ret.setChosenObjective(currentBestChosen);

		return ret;
	}
}
