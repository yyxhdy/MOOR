/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

public class Individual_BS extends Individual {

	boolean[] dv; // the individual's decision vector

	public Individual_BS(int id, int ds_dim, int os_dim, boolean[] dv, double[] ov) {
		this.id = id;
		this.ds_dim = ds_dim;
		this.os_dim = os_dim;
		this.dv = dv;
		this.ov = ov;
	}

	public Individual_BS(int id, int ds_dim, int os_dim) {
		this.id = id;
		this.ds_dim = ds_dim;
		this.os_dim = os_dim;
		this.dv = new boolean[ds_dim];
		this.ov = new double[os_dim];
	}

	public boolean[] getDecisionVector() {
		return dv;
	}

	public void setDecisionVector(boolean[] dv) {
		this.dv = dv;
	}

	public String toString() {
		String str = id + ": ";
		for (int i = 0; i < ds_dim; i++) {
			if (dv[i]) {
				str = str + 1;
			} else {
				str = str + 0;
			}
		}
		str = str + " - ";
		for (int i = 0; i < os_dim; i++) {
			str = str + ov[i] + ", ";
		}
		return str;
	}
}