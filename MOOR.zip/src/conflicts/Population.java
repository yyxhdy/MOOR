/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

import java.util.LinkedList;
import cern.jet.random.engine.MersenneTwister;
import edu.cornell.lassp.houle.RngPack.RandomElement;

public class Population {
	int ds_dim = 2; // dimension of the decision space
	int mu = 10; // number of individuals in the population

	LinkedList<Individual> ind = new LinkedList<Individual>(); // the
																// individuals
																// in the
																// population

	Problem problem;
	RandomElement seed;

	private void initRandomGenerator() {
		seed = new MersenneTwister((int) System.currentTimeMillis() % 1000);
	}

	public Population() {
		initRandomGenerator();
	}

	protected RandomElement getRandomElement() {
		return new MersenneTwister(seed.choose(Integer.MIN_VALUE, Integer.MAX_VALUE));
	}

	public int getDecisionSpaceDimension() {
		return ds_dim;
	}

	public LinkedList<Individual> getPopulation() {
		return ind;
	}

	public int getPopulationsize() {
		return mu;
	}

	public Problem getProblem() {
		return problem;
	}

	public void addIndividual(Individual ind) {
		this.ind.add(ind);
	}

}
