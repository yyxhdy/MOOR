/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

import cern.jet.random.engine.MersenneTwister;
import edu.cornell.lassp.houle.RngPack.RandomElement;

public class FirstExperiments {

	RandomElement re;

	void firstExperiments(int n, int k_min, int k_max, int k_step, int iterations, int problem, int algo,
			double relation) {
		RandomElement newseed = new MersenneTwister((int) System.currentTimeMillis());
		this.firstExperiments(n, k_min, k_max, k_step, iterations, problem, algo, relation,
				newseed.choose(Integer.MIN_VALUE, Integer.MAX_VALUE));
	}

	void firstExperiments(int n, int k_min, int k_max, int k_step, int iterations, int problem, int algo,
			double relation, int seed) {
		double average = 0;
		this.re = new MersenneTwister(seed);
		int dominanceRelation = 1;

		switch (problem) {
		case 0:
			System.out.println("RandomProblem with objective values in [0,1]");
			break;
		case 1:
			System.out.println("RandomProblem with objective values in {0,1}");
			break;
		}
		switch (algo) {
		case 0:
			System.out.println("exact algorithm");
			break;
		case 1:
			System.out.println("greedy algorithm");
			break;
		}
		if (relation == -1) {
			System.out.println("Dominance relation: weak dominance");
			dominanceRelation = Controller.WEAK_DOMINANCE;
		} else {
			if (relation >= 0) {
				System.out.println("Dominance relation: " + relation + "-dominance");
				dominanceRelation = Controller.EPSILON_DOMINANCE;
			} else {
				System.out.println("ERROR OCCURED: epsilon < 0");
			}
		}
		if (n < 0) {
			System.out.println("Number of Individuals is always " + Math.pow(2, -n)
					+ " and the population equals the whole decision space");
		} else {
			System.out.println("Number of Individuals is always " + n);
		}
		System.out.println("k_min: " + k_min);
		System.out.println("k_max: " + k_max);
		System.out.println("k_step: " + k_step);
		System.out.println("Random seed for the MersenneTwister: " + seed);
		System.out.println("Each experiments is iterated " + iterations
				+ " times with the same parameters but different random seeds");
		System.out.println("______________________________________________________");
		System.out.println("------------------------------------------------------");
		for (int k = k_min; k < k_max; k += k_step) {
			Problem_BS prob;
			Population pop;
			Controller con;
			System.out.println("number of objectives: " + k);
			average = 0;
			java.util.Calendar calendar = new java.util.GregorianCalendar();
			long milliseconds = calendar.getTimeInMillis();
			for (int i = 0; i < iterations; i++) {
				switch (problem) {
				case 0:
					prob = new RandomProblem_BS(k, re);
					break;
				case 1:
					prob = new RandomProblem_BS_discrete(k, re);
					break;
				default:
					prob = new RandomProblem_BS(k, re);
					pop = new Population_BS(n, prob);
					System.out.println("Default...");
				}
				if (n < 0) {
					pop = new Population_BS(-n, prob);
				} else {
					pop = new Population_BS(n, (((int) (Math.log(n) / Math.log(2))) + 1), prob);
				}
				con = new Controller(prob, 1, pop, dominanceRelation, relation);

				if (algo == 0) {
					average = average + con.exactAlgorithm().size();
				} else if (algo == 1) {
					average = average + con.greedyAlgorithm().size();
				}

			}

			average = average / iterations;
			System.out.println("average number of objectives needed: " + average);
			java.util.Calendar calendar2 = new java.util.GregorianCalendar();
			long millis = calendar2.getTimeInMillis();
			System.out.println("Elapsed time during computation: " + (millis - milliseconds) + " milliseconds");
			System.out.println("--------------------------------------------------------");
		}
	}

	/**
	 * Performs the algorithms of bz2007d for the results on the random problem.
	 * 
	 * usage `FirstExperiments n k_min k_max k_step iterations problem algo
	 * relation seed` or `FirstExperiments n k_min k_max k_step iterations
	 * problem algo relation`
	 * 
	 * where
	 * 
	 * - n: decision space dimension if n<0 then the population is the whole
	 * search space of dimension |n| if n>0 then the population size is n - k:
	 * objective space dimension from k_min up to k_max in steps of k_step -
	 * each parameter set is iterated for iterations times - problem=0:
	 * RandomProblem with values in [0,1] problem=1: RandomProblem with values
	 * in {0,1} - algo=0: exact algorithm algo=1: greedy algorithm - relation ==
	 * -1: weak dominance relation relation == epsilon >= 0: epsilon-dominance -
	 * seed: random seed for the Mersenne Twister
	 * 
	 */
	public static void main(String[] args) {
		if (args == null || args.length < 8 || args.length > 9) {
			System.out.println("Wrong syntax.");
			System.out.println();
			System.out.println("Usage:");
			System.out.println("   FirstExperiments n k_min k_max k_step iterations problem algo relation seed");
			System.out.println("   or");
			System.out.println("   FirstExperiments n k_min k_max k_step iterations problem algo relation");
			System.out.println();
			System.out.println("   if n<0 then the population is the whole search space of dimension |n|");
			System.out.println("   if n>0 then the population size is n");
			System.out.println("   k: objective space dimension from k_min up to k_max in steps of k_step");
			System.out.println("   each parameter set is iterated for iterations times");
			System.out.println("   problem==0: RandomProblem with objective values in [0,1]");
			System.out.println("   problem==1: RandomProblem with objective values in {0,1}");
			System.out.println("   algo==0: exact algorithm");
			System.out.println("   algo==1: greedy algorithm");
			System.out.println(
					"   relation is a double value, iff =-1 the dominance relation is the weak dominance relation");
			System.out.println("      if relation = epsilon > 0 then the relation is the epsilon-dominance relation");
			System.out.println("   seed: random seed for the Mersenne Twister");
		} else if (args.length == 9) {
			FirstExperiments fi = new FirstExperiments();
			fi.firstExperiments((new Integer(args[0]).intValue()), (new Integer(args[1]).intValue()),
					(new Integer(args[2]).intValue()), (new Integer(args[3]).intValue()),
					(new Integer(args[4]).intValue()), (new Integer(args[5]).intValue()),
					(new Integer(args[6]).intValue()), (new Double(args[7]).doubleValue()),
					(new Integer(args[8]).intValue()));
		} else if (args.length == 8) {
			FirstExperiments fi = new FirstExperiments();
			fi.firstExperiments((new Integer(args[0]).intValue()), (new Integer(args[1]).intValue()),
					(new Integer(args[2]).intValue()), (new Integer(args[3]).intValue()),
					(new Integer(args[4]).intValue()), (new Integer(args[5]).intValue()),
					(new Integer(args[6]).intValue()), (new Double(args[7]).doubleValue()));
		}
	}

}