/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

/**
 * Computes the maximal spread of a given population:
 * 
 * max_spread = max_i [ max_p (f_i(p)) - min_p (f_i(p)) ]
 * 
 * 
 * Attention: only works for population of at least 2 individuals and at least 2
 * objectives
 * 
 * Usage:
 * 
 * MaxSpreadCalculator filename
 * 
 */
public class MaxSpreadCalculator {

	public static void main(String[] args) {
		if (args == null || args.length != 1) {
			System.out.println("Wrong usage.");
			System.out.println();
			System.out.println("Usage:");
			System.out.println("   MaxSpreadCalculator filename");
		} else {

			String filename = args[0];
			FileProblem problem = new FileProblem(filename);
			FilePopulation pop = new FilePopulation(problem);
			DeltaMOSSGreedyAlgorithm dmga = new DeltaMOSSGreedyAlgorithm(pop);
			double[][] m = dmga.values;
			double[] max = new double[m[0].length];
			double[] min = new double[m[0].length];
			for (int i = 0; i < max.length; i++) {
				max[i] = Double.NEGATIVE_INFINITY;
				min[i] = Double.POSITIVE_INFINITY;
			}
			for (int i = 0; i < m.length; i++) {
				for (int j = 0; j < m[0].length; j++) {
					max[j] = Math.max(max[j], m[i][j]);
					min[j] = Math.min(min[j], m[i][j]);
				}
			}
			double maximum = Double.NEGATIVE_INFINITY;
			double minimum = Double.POSITIVE_INFINITY;
			double[] diff = new double[max.length];
			for (int i = 0; i < max.length; i++) {
				diff[i] = Math.abs(max[i] - min[i]);
				if (max[i] > maximum) {
					maximum = max[i];
				}
				if (min[i] < minimum) {
					minimum = min[i];
				}
			}
			double diffmax = Double.NEGATIVE_INFINITY;
			for (int i = 0; i < diff.length; i++) {
				diffmax = Math.max(diffmax, diff[i]);
			}
			System.out.println("The minimal and maximal values in " + filename + " are");
			System.out.println("Min= " + minimum);
			System.out.println("Max= " + maximum);
			System.out.println("and the maximal spread of the population is " + diffmax);
		}
	}

}
