package jmetal.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.encodings.variable.Binary;

public class ObjResNode implements Comparable<ObjResNode> {
	int nobj;
	double error;
	List<Integer> objList;

	public ObjResNode(int nobj, double error, List<Integer> objList) {
		this.nobj = nobj;
		this.error = error;
		this.objList = new ArrayList<Integer>(objList.size());
		for (int i = 0; i < objList.size(); i++)
			this.objList.add(objList.get(i));
	}
	
	public ObjResNode(Solution solution) {
		Binary code = (Binary) (solution.getDecisionVariables()[0]);
		this.objList = new ArrayList<Integer>();
		for (int i = 0; i < code.getNumberOfBits(); i++) {
			if (code.getIth(i))
				this.objList.add(i);		
		}
		
		this.nobj = (int)solution.getObjective(1);
		this.error = solution.getObjective(0);
	}
	
	
	public int compareTo(ObjResNode node) {
		if (nobj < node.nobj)
			return -1;
		else if (nobj > node.nobj)
			return 1;
		else
			return 0;
	}
	
	public int getNumberOfObjectives() {
		return nobj;
	}
	
	public double getError() {
		return error;
	}
	
	public List<Integer> getObjectives() {
		return objList;
	}
	
	
	public static List<ObjResNode> getMOObjRedAlgResults(SolutionSet population) {
		List<ObjResNode> res = new ArrayList<ObjResNode>();
		
		for (int i = 0; i < population.size(); i++) {
			Solution sol = population.get(i);
			
			ObjResNode node = new ObjResNode(sol);
			
			boolean flag = false;
			
			for (int j = 0; j < res.size(); j++) {
				if (isEqual(node, res.get(j))) {
					flag = true;
					break;
				}
			}
			
			if (!flag)
				res.add(node);
		}
		
		Collections.sort(res);
		
		return res;
	}
	
	public static boolean isEqual(ObjResNode o1, ObjResNode o2) {
		if (o1.nobj != o2.nobj)
			return false;
		if (o1.error != o2.error)
			return false;
		
		if (o1.objList.size() != o2.objList.size())
			return false;
		
		for (int i = 0; i < o1.objList.size(); i++) {
			if (o1.objList.get(i) != o2.objList.get(i))
				return false;
		}
		return true;
	}
	
	
	
	
	
}
