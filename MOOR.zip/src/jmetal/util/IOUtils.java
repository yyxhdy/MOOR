package jmetal.util;

import java.io.*;
import java.util.List;

import conflicts.sets.ObjectiveSet;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;

public class IOUtils {
	static public void appendObjectToFile(String fileName, Object object) {
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(fileName, true);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			BufferedWriter bw = new BufferedWriter(osw);

			bw.write(object.toString());
			bw.newLine();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static public void createEmtpyFile(String fileName) {
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(fileName, false);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			BufferedWriter bw = new BufferedWriter(osw);

			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	static public SolutionSet getPopulationFromFile(String filePath) throws IOException {
		SolutionSet pop = new SolutionSet();   
		FileReader fr = new FileReader(filePath);
		BufferedReader br = new BufferedReader(fr);
		String aux = br.readLine();
		
		while (aux != null) {
			String[] st = aux.split("\\s+");
			Solution sol = new Solution(st.length);
			for (int j = 0; j < st.length; j++) {
				double val = Double.parseDouble(st[j]);
				sol.setObjective(j, val);

			}
			pop.add(sol);

			aux = br.readLine();
		}
		br.close();

		return pop;
	}
	
	
	public static SolutionSet getPopulationFromOrgFile(String filePath) throws IOException {
		SolutionSet pop = new SolutionSet();
		FileReader fr = new FileReader(filePath);
		BufferedReader br = new BufferedReader(fr);

		
		br.readLine();
		br.readLine();
		
		String aux = br.readLine();
		
		while (aux != null) {
			String[] st = aux.split("\\s+");
			Solution sol = new Solution(st.length - 1);
			for (int j = 1; j < st.length; j++) {
				double val = Double.parseDouble(st[j]);
				sol.setObjective(j - 1, val);

			}

			pop.add(sol);

			aux = br.readLine();
		}
		br.close();

		return pop;
	}
	
	
	static public void printObjectiveSet(ObjectiveSet set) {
		System.out.println("k\tError\tObj Set");
		System.out.println("------------------------");
		
		System.out.print(set.size() + "\t" + String.format("%.4f", set.getDelta()) + "\t");
		
		for (int i = 0; i < set.getElements().length; i++) {
			if (set.getElements()[i]) 
				System.out.print(i + " ");
		}
		System.out.println();
	}
	static public void printMOObjRedAlgResults(SolutionSet population) {
		List<ObjResNode> res = ObjResNode.getMOObjRedAlgResults(population);
		
		System.out.println("k\tError\tObj Set");
		System.out.println("------------------------");
		for (int i = 0; i < res.size(); i++) {
			ObjResNode node = res.get(i);
			System.out.print(node.getNumberOfObjectives() + "\t");
			System.out.print(String.format("%.4f", node.getError()) + "\t");
			for (int j = 0; j < node.getObjectives().size() - 1; j++)
				System.out.print(node.getObjectives().get(j) + ",");
			System.out.println(node.getObjectives().get(node.getObjectives().size() - 1));
		}
	}
	
	
	static public SolutionSet getNormalizedPopulationFromFile(String path) throws IOException {
		SolutionSet population = getPopulationFromFile(path);
		return getNormalizedPopulation(population);
	}
	
	
	static public SolutionSet getNormalizedPopulation(SolutionSet population) {
		SolutionSet normalizedPopulation = new SolutionSet(population.size());
		int nobj = population.get(0).getNumberOfObjectives();
		
		double max[] = new double[nobj];
		double min[] = new double[nobj];
		
		for (int j = 0; j < nobj; j++) {
			max[j] = -Double.MAX_VALUE;
			min[j] = Double.MAX_VALUE;
		}
		
		for (int i = 0; i < population.size(); i++) {
			for (int j = 0; j < nobj; j++) {
				if (population.get(i).getObjective(j) > max[j])
					max[j] = population.get(i).getObjective(j);
				if (population.get(i).getObjective(j) < min[j])
					min[j] = population.get(i).getObjective(j);
			}
		}
		
		for (int i = 0; i < population.size(); i++) {
			Solution sol = population.get(i);
			Solution newSol = new Solution(sol.getNumberOfObjectives());

			for (int j = 0; j < nobj; j++)
				newSol.setObjective(j, (sol.getObjective(j) - min[j])
						/ (max[j] - min[j]));
			normalizedPopulation.add(newSol);
		}
		
		return normalizedPopulation;
	}
	
}
