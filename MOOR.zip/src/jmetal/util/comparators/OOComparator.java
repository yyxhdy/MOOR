package jmetal.util.comparators;

import java.util.Comparator;

import jmetal.core.Solution;

public class OOComparator implements Comparator {
	private int i;
	private int j;
	
	public OOComparator(int i, int j) {
		this.i = i;
		this.j = j;
	}
	@Override
	public int compare(Object o1, Object o2) {
		if (o1 == null)
			return 1;
		else if (o2 == null)
			return -1;
		
		double objetive1 = ((Solution) o1).getObjective(this.i);
		double objetive2 = ((Solution) o2).getObjective(this.i);
		
		double ao1 = ((Solution) o1).getObjective(this.j);
		double ao2 = ((Solution) o2).getObjective(this.j);
		
		if (objetive1 < objetive2) {
			return -1;
		} else if (objetive1 > objetive2) {
			return 1;
		} else {
			if (ao1 < ao2)
				return -1;
			else if (ao1 > ao2)
				return 1;
			else
				return 0;
		}
	}

}
