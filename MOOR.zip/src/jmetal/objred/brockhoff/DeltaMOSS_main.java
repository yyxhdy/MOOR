package jmetal.objred.brockhoff;

import java.io.IOException;

import jmetal.core.SolutionSet;
import jmetal.util.IOUtils;
import conflicts.sets.ObjectiveSet;

public class DeltaMOSS_main {
	public static void main(String args[]) throws IOException {
		SolutionSet pop = IOUtils.getPopulationFromFile("SampleSet/D5(3,5)_N1.txt"); // read the sample set from file
		pop = IOUtils.getNormalizedPopulation(pop); // normalization 
		
		ObjectiveSet set1, set2, set3, set4;
		
		int k = 4;   // the predefined k
		double delta = 0;  // the predefined delta
		
		DeltaMOSSGreedyWrapper greedy = new DeltaMOSSGreedyWrapper(pop);  // initial the greedy algorithm
		DeltaMOSSExactWrapper exact = new DeltaMOSSExactWrapper(pop);   // initial the exact algorithm
		
		set1 = greedy.performGreedyAlgorithmGivenDelta(delta);  // using greedy algorithm for delta-MOSS
		set2 = greedy.performGreedyAlgorithmGivenK2(k);        // using greedy algorithm for k-EMOSS
		
		
		/* Note: the exact algorithm is not applicable for larger instance, e.g., DTLZ5(6,20) */
		set3 = exact.performExactAlgorithmGivenDelta(delta);  // using exact algorithm for delta-MOSS
		set4 = exact.performExactAlgorithmGivenK(k);    // using exact algorithm for k-EMOSS
		
		
		IOUtils.printObjectiveSet(set1);  // output the obtained objective subset
	}
}
