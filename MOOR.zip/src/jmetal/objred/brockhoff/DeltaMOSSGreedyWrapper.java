package jmetal.objred.brockhoff;

import conflicts.DeltaMOSSGreedyAlgorithm;
import conflicts.FileProblem;
import conflicts.sets.ObjectiveSet;
import jmetal.core.SolutionSet;


public class DeltaMOSSGreedyWrapper {
	DeltaMOSSGreedyAlgorithm greedyAlg;
	
	public DeltaMOSSGreedyWrapper(String filePath) {
		FileProblem fp = new FileProblem(filePath);
		double[][] tempPoints = fp.getPoints();
		
		double[][] points = new double[tempPoints.length][tempPoints[0].length - 1];
		
		for (int i = 0; i < points.length; i++) {
			for (int j = 0; j < points[i].length; j++)
				points[i][j] = tempPoints[i][j + 1];
		}
		
		greedyAlg = new DeltaMOSSGreedyAlgorithm(points);		
		
	}
	
	public DeltaMOSSGreedyWrapper(SolutionSet population) {
		int n = population.size();
		int m = population.get(0).getNumberOfObjectives();
		double[][] points = new double[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++)
				points[i][j] = population.get(i).getObjective(j);
		}
		greedyAlg = new DeltaMOSSGreedyAlgorithm(points);
	}
	
	public ObjectiveSet performGreedyAlgorithmGivenDelta(double delta) {
		return greedyAlg.performGreedyAlgorithmGivenDelta(delta);
	}
	
	public ObjectiveSet performGreedyAlgorithmGivenK(int k) {
		return greedyAlg.performGreedyAlgorithmGivenK(k);
	}
	
	public ObjectiveSet performGreedyAlgorithm() {
		return performGreedyAlgorithmGivenDelta(0);
	}
	
	
	public void computeTree(int method) {
		greedyAlg.computeTree(method);
	}
	
	public ObjectiveSet performGreedyAlgorithmGivenK2(int k) {
		return greedyAlg.computeTreeWithPairwiseComparison(k);
	}
	
	public ObjectiveSet performGreedyAlgorithmGivenK3(int k) {
		return greedyAlg.computeTreeWithAllCombinationsK(k);
	}
	
}
