package jmetal.objred.brockhoff;

import conflicts.DeltaMOSSExactAlgorithm;
import conflicts.FilePopulation;
import conflicts.FileProblem;
import conflicts.Relation;
import conflicts.sets.ObjectiveSet;
import conflicts.sets.SetOfObjectiveSets;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;

public class DeltaMOSSExactWrapper {
	DeltaMOSSExactAlgorithm exactAlg;
	
	public DeltaMOSSExactWrapper(String filePath) {
		FileProblem fp = new FileProblem(filePath);
		FilePopulation pop = new FilePopulation(fp);

		double[][] tempPoints = fp.getPoints();
		double[][] points = new double[tempPoints.length][tempPoints[0].length - 1];

		for (int i = 0; i < points.length; i++) {
			for (int j = 0; j < points[0].length; j++) {
				points[i][j] = tempPoints[i][j + 1];
			}
		}

		int os_dim = pop.getPopulation().get(0).getObjectiveVector().length;

		Relation[] relations = new Relation[os_dim];

		int size = points.length;

		for (int i = 0; i < os_dim; i++) {
			relations[i] = new Relation(i, size);
			for (int j = 0; j < size; j++) {
				for (int k = 0; k < size; k++) {
					if (points[j][i] <= points[k][i]) {
						relations[i].setinrelation(j, k, true);
					} else {
						relations[i].setinrelation(j, k, false);
					}
				}
			}
		}

		exactAlg = new DeltaMOSSExactAlgorithm(pop, os_dim, relations);
	}
	
	public DeltaMOSSExactWrapper(SolutionSet population) {
		
		int os_dim = population.get(0).getNumberOfObjectives();
		int size = population.size();
		double[][] points = new double[size][os_dim];
		
		for (int i = 0; i < points.length; i++) {
			for (int j = 0; j < points[i].length; j++)
				points[i][j] = population.get(i).getObjective(j);
		}
		
		Relation[] relations = new Relation[os_dim];

		for (int i = 0; i < os_dim; i++) {
			relations[i] = new Relation(i, size);
			for (int j = 0; j < size; j++) {
				for (int k = 0; k < size; k++) {
					if (points[j][i] <= points[k][i]) {
						relations[i].setinrelation(j, k, true);
					} else {
						relations[i].setinrelation(j, k, false);
					}
				}
			}
		}
		
		FilePopulation pop = new FilePopulation(population);
		
		
		exactAlg = new DeltaMOSSExactAlgorithm(pop, os_dim, relations);
		
		
	}
	
	public ObjectiveSet performExactAlgorithmGivenDelta(double delta) {
		return exactAlg.performExactAlgorithmGivenDelta(delta);
	}
	
	public ObjectiveSet performExactAlgorithmGivenK(int k) {
		return exactAlg.performExactAlgorithmGivenK(k);
	}
	
	public ObjectiveSet performExactAlgorithm() {
		return performExactAlgorithmGivenDelta(0);
	}
	
	public SetOfObjectiveSets getAllMinimalSets(int type, double value) {
		return exactAlg.getAllMinimalSets(type, value);
	}
	
	public SetOfObjectiveSets getAllMinimalSets() {
		return exactAlg.getAllMinimalSets(2, exactAlg.getNumberOfObjectives());
	}
	
	public static void main(String args[]) {
/*		DeltaMOSSExactWrapper dmg = new DeltaMOSSExactWrapper("SPEA2SDE_DTLZ5_5_11_v2.txt");
		int K =5;
		
	//	System.out.println(K);
		long initTime = System.currentTimeMillis();
	//	ObjectiveSet set = dmg.performExactAlgorithmGivenK(K);
		ObjectiveSet set = dmg.performExactAlgorithmGivenDelta(0.5);
		long estimatedTime = System.currentTimeMillis() - initTime;
		  
		System.out.println("Total execution time: " + estimatedTime + "ms");
		
		System.out.println(set);

		System.out.println(set.getDelta());*/
		
		Solution s1 = new Solution(5);
		s1.setObjective(0, 3);
		s1.setObjective(1, 1);
		s1.setObjective(2, 1);
		s1.setObjective(3, 2);
		s1.setObjective(4, 3);
		
		Solution s2 = new Solution(5);
		s2.setObjective(0, 2);
		s2.setObjective(1, 2);
		s2.setObjective(2, 2);
		s1.setObjective(3, 2);
		s1.setObjective(4, 3);
		
		
		Solution s3 = new Solution(5);
		s3.setObjective(0, 2);
		s3.setObjective(1, 3);
		s3.setObjective(2, 0);
		s1.setObjective(3, 1);
		s1.setObjective(4, 4);
		
		SolutionSet pop = new SolutionSet(3);
		pop.add(s1);
		pop.add(s2);
		pop.add(s3);
		
		DeltaMOSSExactWrapper dd = new DeltaMOSSExactWrapper(pop);
		
		ObjectiveSet sett = dd.performExactAlgorithmGivenDelta(3);
		
		System.out.println(sett);
		
		
	}
}
