package jmetal.problems;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.encodings.solutionType.BinarySolutionType;
import jmetal.encodings.variable.Binary;
import jmetal.util.Correlation;
import jmetal.util.IOUtils;
import jmetal.util.JMException;


public class OR_Gamma extends Problem {

	private double[][] conflicts_;

	public OR_Gamma(String solutionType, Integer numberOfBits) {
		numberOfVariables_ = 1;
		numberOfObjectives_ = 2;
		numberOfConstraints_ = 0;
		problemName_ = "Ob_Gamma";

		solutionType_ = new BinarySolutionType(this);

		length_ = new int[numberOfVariables_];
		length_[0] = numberOfBits;

		if (solutionType.compareTo("Binary") == 0)
			solutionType_ = new BinarySolutionType(this);
		else {
			System.out.println("ObjRed2: solution type " + solutionType
					+ " invalid");
			System.exit(-1);
		}

	}

	public OR_Gamma(String solutionType, SolutionSet population) {
		this(solutionType, population.get(0).getNumberOfObjectives());
		setSamplePopulation(population);
	}

	public OR_Gamma(String solutionType, String filePath) throws IOException {
		SolutionSet population = IOUtils.getPopulationFromFile(filePath);

		numberOfVariables_ = 1;
		numberOfObjectives_ = 2;
		numberOfConstraints_ = 0;
		problemName_ = "OR_Gamma";

		solutionType_ = new BinarySolutionType(this);

		length_ = new int[numberOfVariables_];
		length_[0] = population.get(0).getNumberOfObjectives();

		if (solutionType.compareTo("Binary") == 0)
			solutionType_ = new BinarySolutionType(this);
		else {
			System.out.println("OR_Gamma: solution type " + solutionType
					+ " invalid");
			System.exit(-1);
		}

		setSamplePopulation(population);
	}

	public void setSamplePopulation(SolutionSet population) {
		computeConflicts(population);
	}

	
	
	public void evaluate(Solution solution) throws JMException {
		Binary code = (Binary) (solution.getDecisionVariables()[0]);
		List<Integer> center = new ArrayList<Integer>();
		for (int i = 0; i < code.getNumberOfBits(); i++) {
			if (code.getIth(i))
				center.add(i);
		}

		if (center.size() == 0) {
			solution.setObjective(0, Double.MAX_VALUE);
			solution.setObjective(1, Integer.MAX_VALUE);
			return;
		}
		
		double maxConflict = 0;
		for (int i = 0; i < length_[0]; i++) {
			if (center.contains(i))
				continue;

			double min = Double.MAX_VALUE;
			for (int k = 0; k < center.size(); k++) {
				if (conflicts_[i][center.get(k)] < min) 
					min = conflicts_[i][center.get(k)];
			}
			
			if (min > maxConflict)
				maxConflict = min;	
		}
		
		solution.setObjective(0, maxConflict);
		solution.setObjective(1, center.size());
	}

	
	public void computeConflicts(SolutionSet population) {
		int nobj = length_[0];
		conflicts_ = new double[nobj][nobj];

		for (int i = 0; i < nobj; i++) {
			conflicts_[i][i] = 0;
			for (int j = i + 1; j < nobj; j++) {
				double ro = computeKendallCorrelationCoefficient(population, i, j);
				conflicts_[i][j] = 0.5 * (1 - ro);
				conflicts_[j][i] = conflicts_[i][j];
			}
		}
	}
	
	
	
	double computeKendallCorrelationCoefficient(SolutionSet population, int i, int j) {
		double x[] = new double[population.size()];
		double y[] = new double[population.size()];

		for (int k = 0; k < population.size(); k++) {
			x[k] = population.get(k).getObjective(i);
			y[k] = population.get(k).getObjective(j);
		}
		return Correlation.kendallTauBeta(x, y);
	}

}
