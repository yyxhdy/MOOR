package jmetal.problems;

import java.io.IOException;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.encodings.solutionType.BinarySolutionType;
import jmetal.encodings.variable.Binary;
import jmetal.util.IOUtils;
import jmetal.util.PORanking;

public class OR_Eta extends Problem {
	
	private SolutionSet population_;
	

	public OR_Eta(String solutionType, Integer numberOfBits) {
		numberOfVariables_ = 1;
		numberOfObjectives_ = 2;
		numberOfConstraints_ = 0;
		problemName_ = "OR_Eta";

		solutionType_ = new BinarySolutionType(this);

		length_ = new int[numberOfVariables_];
		length_[0] = numberOfBits;

		if (solutionType.compareTo("Binary") == 0)
			solutionType_ = new BinarySolutionType(this);
		else {
			System.out.println("OR_Eta: solution type " + solutionType
					+ " invalid");
			System.exit(-1);
		}

	}

	public OR_Eta(String solutionType, SolutionSet population) {
		this(solutionType, population.get(0).getNumberOfObjectives());
		setSamplePopulation(population);
	}

	public OR_Eta(String solutionType, String filePath) throws IOException {
		SolutionSet population = IOUtils.getPopulationFromFile(filePath);
		
		numberOfVariables_ = 1;
		numberOfObjectives_ = 2;
		numberOfConstraints_ = 0;
		problemName_ = "OR_Eta";

		solutionType_ = new BinarySolutionType(this);

		length_ = new int[numberOfVariables_];
		length_[0] = population.get(0).getNumberOfObjectives();

		if (solutionType.compareTo("Binary") == 0)
			solutionType_ = new BinarySolutionType(this);
		else {
			System.out.println("OR_Eta: solution type " + solutionType
					+ " invalid");
			System.exit(-1);
		}
		
		
		setSamplePopulation(population);
	}

	public void setSamplePopulation(SolutionSet population) {
		this.population_ = population;
	}
	
	
	
	
	public void evaluate(Solution solution) {
		Binary code = (Binary) (solution.getDecisionVariables()[0]);
		int k = 0;

		for (int i = 0; i < code.getNumberOfBits(); i++) {
			if (code.getIth(i))
				k++;
		}

		if (k == 0) {
			solution.setObjective(0, Double.MAX_VALUE);
			solution.setObjective(1, Integer.MAX_VALUE);
			return;
		}
		
		PORanking poRanking = new PORanking(population_, solution);
		SolutionSet pop = poRanking.getSubfront(0);
		
		solution.setObjective(0,  (double)(population_.size() - pop.size()) / population_.size());
		
		solution.setObjective(1, k);
		
	}
}
