package jmetal.problems;


import java.io.IOException;



import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.encodings.solutionType.BinarySolutionType;
import jmetal.encodings.variable.Binary;
import jmetal.util.IOUtils;
import jmetal.util.JMException;
import jmetal.util.comparators.EqualSolutions;
import jmetal.util.comparators.POEqualSolutions;

public class OR_Delta extends Problem {
	private SolutionSet population_;

	private double[][] delta_;

	private boolean[][] nonComparable_;

	private static final EqualSolutions equal_ = new EqualSolutions();
	private static POEqualSolutions poequal_;

	public OR_Delta(String solutionType, Integer numberOfBits) {
		numberOfVariables_ = 1;
		numberOfObjectives_ = 2;
		numberOfConstraints_ = 0;
		problemName_ = "OR_Delta";

		solutionType_ = new BinarySolutionType(this);

		length_ = new int[numberOfVariables_];
		length_[0] = numberOfBits;

		if (solutionType.compareTo("Binary") == 0)
			solutionType_ = new BinarySolutionType(this);
		else {
			System.out.println("OR_Delta: solution type " + solutionType
					+ " invalid");
			System.exit(-1);
		}

	}

	public OR_Delta(String solutionType, SolutionSet population) {
		this(solutionType, population.get(0).getNumberOfObjectives());
		setSamplePopulation(population);
	}

	public OR_Delta(String solutionType, String filePath) throws IOException {
		SolutionSet population = IOUtils.getPopulationFromFile(filePath);
		
		numberOfVariables_ = 1;
		numberOfObjectives_ = 2;
		numberOfConstraints_ = 0;
		problemName_ = "OR_Delta";

		solutionType_ = new BinarySolutionType(this);

		length_ = new int[numberOfVariables_];
		length_[0] = population.get(0).getNumberOfObjectives();

		if (solutionType.compareTo("Binary") == 0)
			solutionType_ = new BinarySolutionType(this);
		else {
			System.out.println("OR_Delta: solution type " + solutionType
					+ " invalid");
			System.exit(-1);
		}
		
		
		setSamplePopulation(population);
	}

	public void setSamplePopulation(SolutionSet population) {
		this.population_ = population;
		computeRG(population);
	}

	@Override
	public void evaluate(Solution solution) throws JMException {
		Binary code = (Binary) (solution.getDecisionVariables()[0]);

		int k = 0;

		for (int i = 0; i < code.getNumberOfBits(); i++) {
			if (code.getIth(i))
				k++;
		}

		if (k == 0) {
			solution.setObjective(0, Double.MAX_VALUE);
			solution.setObjective(1, Integer.MAX_VALUE);
			return;
		}

		int n = population_.size();

		double delta = 0;

		poequal_ = new POEqualSolutions(solution);
		for (int i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++) {
				if (nonComparable_[i][j]) {
					int flag = poequal_.compare(population_.get(i),
							population_.get(j));

					if (flag == -1) {
						if (delta_[i][j] > delta)
							delta = delta_[i][j];
					} else if (flag == 1) {
						if (delta_[j][i] > delta)
							delta = delta_[j][i];
					} else if (flag == 2) {
						double max = Math.max(delta_[i][j], delta_[j][i]);
						if (max > delta)
							delta = max;
					}
				}
			}
		}

		solution.setObjective(0, delta);
		solution.setObjective(1, k);
	}

	void computeRG(SolutionSet pop) {
		int n = pop.size();

		delta_ = new double[n][n];

		nonComparable_ = new boolean[n][n];

		for (int i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++) {
				Solution s1 = pop.get(i);
				Solution s2 = pop.get(j);
				int flag = equal_.compare(s1, s2);

				if (flag == 0) {
					nonComparable_[i][j] = nonComparable_[j][i] = true;

					double[] deltas = getDeltas(s1, s2);

					delta_[i][j] = deltas[0];
					delta_[j][i] = deltas[1];
				}
			}
		}
	}
	
	double[] getDeltas(Solution s1, Solution s2) {
		double[] deltas = new double[2];

		double max = 0;
		double min = 0;

		int nobj = s1.getNumberOfObjectives();

		for (int i = 0; i < nobj; i++) {
			double val = s1.getObjective(i) - s2.getObjective(i);
			if (val > 0 && val > max)
				max = val;
			else if (val < 0 && val < min)
				min = val;
		}
		deltas[0] = max;
		deltas[1] = -min;

		return deltas;

	}
}

